from slack_webhook import Slack

def slack_alert(file_name_unknown):
	slack = Slack(url='https://hooks.slack.com/services/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')
	slack.post(text=str(file_name_unknown))
	#print('working')